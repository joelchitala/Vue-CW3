const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  publicPath:'/Vue-CW3/',
  transpileDependencies: true
})
